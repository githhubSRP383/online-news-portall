<footer class="sticky-footer bg-white">
   <div class="container my-auto">
      <div class="copyright text-center my-auto">
      <span> <?php echo date("Y"); ?> &copy; Online News Portaligniter</span>
      </div>
   </div>
</footer>